## View the Application

- Once the deployment is successful, you can view the application by navigating to the Elastic Beanstalk environment URL.
- You can our application running on the Elastic Beanstalk environment.
- Below is the screenshot of the my application running on the Elastic Beanstalk environment.

![step-2 33](https://github.com/mathesh-me/aws-cicd-devops-web-app/assets/144098846/0e16cefd-7876-4e25-a137-49b14035b726)
